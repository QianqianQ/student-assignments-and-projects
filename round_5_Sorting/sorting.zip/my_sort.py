def my_sort(lst):
    """Return the sequence `lst` sorted in-place in ascending order."""
    # Note: in-place means, that the method shouldn't create and return
    # another list, but sort the same list object it received, and
    # return it.
    # It is allowed however, to copy values to another list and use it
    # to get the given list sorted. Note that this will take extra
    # memory though.
    # The solution must be fast in order to complete the biggest sorting
    # problems in time before the time runs out and the evaluator
    # terminates the attempt.
    # Note: If you are implementing a recursive mergesort, remember to
    # divide only up until a certain sublist size, eg. 20, and then sort
    # the sublist with another method, eg. selection sort. Dividing and
    # recursing up until sublists of size 1 is not effective!
    raise NotImplementedError('my_sort does not sort anything yet.')
    return lst
