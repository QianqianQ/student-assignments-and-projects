class Human():
    def __init__(self, first_name, last_name, money, age):
        raise NotImplementedError("Implement this method!")
            
    def return_name(self):
        raise NotImplementedError("Implement this method!")
        
    def increment_age(self):
        raise NotImplementedError("Implement this method!")
        
    def return_age(self):
        raise NotImplementedError("Implement this method!")
    
    def buy_something(self, money):
        raise NotImplementedError("Implement this method!")        
        
    def pay_salary(self, amount):
        raise NotImplementedError("Implement this method!")        
        
    def return_money(self):
        raise NotImplementedError("Implement this method!")        
    
    def return_married_to(self):
        raise NotImplementedError("Implement this method!")
    
    def get_married(self, human):
        raise NotImplementedError("Implement this method!")
    
    def __str__(self):
        raise NotImplementedError("Implement this method!")
    
def create_humans():
    raise NotImplementedError("Implement this function!")

if __name__ == "__main__":
    create_humans()
    
